package baseClass;
import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import fileUtility.PropertyFile;

public class BaseClass
{
	String expectedURL="https://app-staging.nokodr.com/super/apps/auth/v1/index.html#/login";
	public static WebDriver driver;
	PropertyFile p = new PropertyFile();
	
	@BeforeClass
	public void preCondition() throws IOException
	{
		String browser = p.getInputData("Browser");
		String url = p.getInputData("URL");

		if(browser.equalsIgnoreCase("chrome"))
		{
			driver = new ChromeDriver();
		}else if(browser.equalsIgnoreCase("edge"))
		{
			driver = new EdgeDriver();
		}else {
			driver = new ChromeDriver();
		}
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
		driver.get(url);
		String actualURL = driver.getCurrentUrl();
		assertTrue(expectedURL.equals(actualURL));
	}
	@AfterClass
	public void postcondition()
	{
		driver.quit();
	}
}
