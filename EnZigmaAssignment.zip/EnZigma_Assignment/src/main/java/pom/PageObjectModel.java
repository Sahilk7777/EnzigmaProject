package pom;

import java.io.IOException;

import org.apache.poi.EncryptedDocumentException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import fileUtility.ExcelFIle;

public class PageObjectModel
{
	ExcelFIle Exc = new ExcelFIle();
	public PageObjectModel(WebDriver driver) 
	{
		PageFactory.initElements(driver, this);
	}
	
	private @FindBy (xpath = "//a[text()='Sign up']")
	WebElement signuplink;
	
	public WebElement getsignuplink()
	{
		return signuplink;
	}
	
	public void signup()
	{
		signuplink.click();
	}
	
	
	
	private @FindBy (xpath = "(//input[@type='email'])[2]")
	WebElement userEmail;
	
	public WebElement getEmail()
	{
		return userEmail;
	}
	
	public void Email() throws EncryptedDocumentException, IOException
	{
		String Email = Exc.getData("SignUpCredentials", 0, 1);
		userEmail.sendKeys(Email);
	}
	
	private @FindBy (css = "label[class='slds-checkbox__label']")
	WebElement checkBox;
	
	public WebElement getcheckBox()
	{
		return checkBox;
	}
	
	public void clickCheckBox()
	{
		checkBox.click();
	}
	
	
	private @FindBy (xpath = "//div[text()='Proceed']")
	WebElement Proceed ;
	
	public WebElement getProceed()
	{
		return Proceed;
	}
	
	public void clickProceed()
	{
		Proceed.click();
	}
	
	
	///////////////////////////////
	
	private @FindBy (css  = "input[name='firstName']")
	WebElement firstName ;
	
	public WebElement getfirstName()
	{
		return firstName;
	}
	
	public void EnterfirstName() throws EncryptedDocumentException, IOException
	{
		String FirstName = Exc.getData("SignUpCredentials", 1, 1);
		firstName.sendKeys(FirstName);
	}
	
	private @FindBy (css  = "input[name='lastName']")
	WebElement lastName ;
	
	public WebElement getlastName()
	{
		return lastName;
	}
	
	public void EnterlastName() throws EncryptedDocumentException, IOException
	{
		String LastName = Exc.getData("SignUpCredentials", 1, 2);
		lastName.sendKeys(LastName);
	}
	
	
	private @FindBy (xpath   = "//input[@name='password'])[2]")
	WebElement password ;
	
	public WebElement getpassword()
	{
		return password;
	}
	
	public void Enterpassword() throws EncryptedDocumentException, IOException
	{
		String Password = Exc.getData("SignUpCredentials", 1, 3);
		password.sendKeys(Password);
	}
	 
	
	private @FindBy (css  = "input[name='password-confirmpassword']")
	WebElement confirmpassword ;
	
	public WebElement getconfirmpassword()
	{
		return confirmpassword;
	}
	
	public void Enterconfirmpassword() throws EncryptedDocumentException, IOException
	{
		String Confirmpassword = Exc.getData("SignUpCredentials", 1, 4);
		confirmpassword.sendKeys(Confirmpassword);
	}
	
	private @FindBy (xpath   = "//div[text()='Register']")
	WebElement Register ;
	
	public WebElement getRegister()
	{
		return Register;
	}
	
	public void EnterRegister()
	{
		Register.click();
	}
	
	
	
	
	//input[name='password-confirmpassword']
	//input[name='firstName']
	//input[name='lastName']
	//input[@name='password'])[2]
	//div[text()='Register']
	
	
	
	private @FindBy(xpath="//input[@name='code']")
	WebElement verificationCode;
	
	public WebElement getCode()
	{
		return verificationCode;
	}
	
	public void Code()
	{
		verificationCode.click();
	}
	
	private @FindBy(xpath="//div[text()='Verify Code']")
	WebElement VerifyCode;
	
	public WebElement getVCode()
	{
		//VerifyCode.sendKeys("");
		return VerifyCode;
	}
	
	public void VCode()
	{
		VerifyCode.click();
	}
	
	private @FindBy (xpath   = "/html/body/app-root/login/abx-auth-container/div/div[2]/div/abx-login/div/a")
	WebElement forgotpass ;
	
	public WebElement getforgotpass()
	{
		return forgotpass;
	}
	
	public void Clickforgotpass()
	{
		forgotpass.click();
	}
	
	private @FindBy (xpath    = "//div[text()='Log In']")
	WebElement Login ;
	
	public WebElement getLogin()
	{
		return Login;
	}
	
	public void ClickLogin()
	{
		Login.click();
	}
	
	
	
	//Login
		private @FindBy(xpath="//a[text()='Log In']")
		WebElement Loginlink;
		
		public WebElement getLoginLink()
		{
			return Loginlink;
			
		}
		public void clickLogin()
		{
			Loginlink.click();
		}
		
		
		//Email
		private @FindBy(css="input[type='email']")
		WebElement Emails;
		 
		public WebElement emailTextField()
		{
			return Emails;	
		}
		
		public void EnteruserEmail() throws EncryptedDocumentException, IOException
		{
			String userEmail = Exc.getData("SignUpCredentials", 0, 1);
			Emails.sendKeys(userEmail);
		}
		
		public void clickEmail() throws EncryptedDocumentException, IOException
		{
			Emails.click();
		}
		
		//Password
		private @FindBy(xpath="//input[@name='username']")
		WebElement Password;
		
		public WebElement PasswordTextField()
		{
			return Password;	
		}
		
		public void EnteruserPassword() throws EncryptedDocumentException, IOException
		{
			String userPassword = Exc.getData("SignUpCredentials", 3, 1);
			Password.sendKeys(userPassword);
		}
		
		//remember me checkbox
		private @FindBy(xpath="//input[@name='rememberMe']")
		WebElement rememberMe;
		
		public WebElement checkboxRemember()
		{
			return rememberMe;	
		}
		
		public void usercheckboxClick() throws EncryptedDocumentException, IOException
		{
			rememberMe.click();
		}
		
		//login button
		private @FindBy(xpath="//div[text()='Log In']")
		WebElement login;
		
		public WebElement loginClick()
		{
			return login;
		}
		
		public void userloginlinkClick()	
		{
			login.click();
		}
}


