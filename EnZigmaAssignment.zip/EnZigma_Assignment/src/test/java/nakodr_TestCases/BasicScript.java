package nakodr_TestCases;

import java.io.IOException;

import org.testng.annotations.Test;

import baseClass.BaseClass;
import fileUtility.PropertyFile;

public class BasicScript extends BaseClass
{
	PropertyFile p = new PropertyFile();
	@Test
	public void testCase1() throws IOException
	{
		// BasicScript browser and url taken from baseclass 
	}
}
 